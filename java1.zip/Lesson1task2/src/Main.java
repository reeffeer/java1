public class Main {

    public static void main(String[] args) {
        byte a = -109;
        short b = 31975;
        int c = 876;
        long d = 35000000L;
        float e = 56.12f;
        double f = -3.874;
        char g = '\022';
        boolean h = true;
        String j = "bot";
    }
}
