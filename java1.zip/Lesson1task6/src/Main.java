public class Main {

    public static void main(String[] args) {
        System.out.println(result(-12));
    }
    public static boolean result(int a) {
        if(a < 0) {
            return true;
        } else
            return false;
    }
}
