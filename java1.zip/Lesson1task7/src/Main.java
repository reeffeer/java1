public class Main {

    public static void main(String[] args) {
        namePerson("Хосэ");
    }
    public static void namePerson(String name) {
        System.out.println("Привет, " + name + "!");
    }
}
